require("dotenv").config();

const express = require("express");
const app = express();
const host = process.env.HOST;
const port = process.env.PORT;

app.get("/", (req, res, next) => {
  res.send("simple get request");
});

app.listen(port, () => {
  console.log(`server get started ${host}${port}`);
});
