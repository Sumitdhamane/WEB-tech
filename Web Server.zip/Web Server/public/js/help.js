function help() {
  alert("I am ready to help you but dont call me ");
}
